@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Notes</h2>
    <a href="{{ route('notes.create') }}" class="btn btn-primary">Create New Note</a>
    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($notes as $note)
            <tr>
                <td>{{ $note->title }}</td>
                <td>
                    <a href="{{ route('notes.show', $note->id) }}" class="btn btn-info">View</a>
                    <a href="{{ route('notes.edit', $note->id) }}" class="btn btn-warning">Edit</a>
                    <form action="{{ route('notes.destroy', $note->id) }}" method="POST" style="display:inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this note?')">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
