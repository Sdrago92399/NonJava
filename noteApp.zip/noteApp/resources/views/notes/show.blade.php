@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Note Details</h2>
    <h3>{{ $note->title }}</h3>
    <p>{{ $note->content }}</p>
    <a href="{{ route('notes.edit', $note->id) }}" class="btn btn-warning">Edit</a>
    <form action="{{ route('notes.destroy', $note->id) }}" method="POST" style="display:inline">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this note?')">Delete</button>
    </form>
</div>
@endsection
